
#include <stdio.h> 
#include <stdlib.h>
#include <fcntl.h> 
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <unistd.h>
#include <getopt.h>


#define ADDR 0x60

unsigned int position = 0;
int c,hflag;
char *filename = "/dev/i2c-1"; 



void parse_opts(int argc, char **argv)
{	
	
	while((c = getopt(argc,argv,"hp:f:")) != -1)
	{
		switch(c)
		{
			case 'h' : hflag = 1;                               break;				/* help */
			case 'p' : position = atoi(optarg);                 break;
			case 'f' : filename = optarg;                       break;
		}

	}
	if (hflag)
	{
		printf("Usage: i2c-step -f \"DEVICE\" -p POSITION \n");		
	exit(1);
		
	}
}


int main (int argc, char **argv) { 

    int fd; 
    unsigned char buffer[128];
    unsigned char rx_buf[128];
    unsigned int n, err,test; 
    
    parse_opts(argc, argv);
    
    
    if (argc == 0) {
        printf("usage: %s <device> -p POSITION\n", argv[0]);
		    //exit(1);
		}

//    sprintf(filename, argv[0]); 
    printf("device = %s\n", filename);

    int slave_address = ADDR; 

    if ((fd = open(filename, O_RDWR)) < 0) { 
        printf("i2c open error"); 
        return -1; 
    } 

    if (ioctl(fd, I2C_SLAVE, slave_address) < 0) { 
        printf("ioctl I2C_SLAVE error"); 
        return -1; 
    } 


    
      //GestFullStatus1 Command: This Command must be executed before Operating
      buffer[0] = 0x81;   

      if (write(fd, buffer, 1) != 1) { 
         printf("write error 0\n"); 
         return -1; 
      } 
     
     sleep(1);
     
    /* Using I2C Read, equivalent of i2c_smbus_read_byte(file) to get the full_status -->  Not working yet.
     if (read(fd, rx_buf, 8) != 8) {
     printf("Error getting FullStatus1.\n");
    } else {
     printf("\nFull Status is: %s \n", rx_buf);
    }
    */
    
      //RunInit command:  This Command must be executed before Operating
      buffer[0] = 0x88; 

      if (write(fd, buffer, 1) != 1) { 
         printf("write error 1\n"); 
         return -1; 
      } 



      printf("Position is: %i\n", position); //Print the Position
        
      
//SetPosition
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable
buffer[2] = 0xff;   // not avialable 
buffer[3] = (unsigned char) (position >> 8);  // PositionByte1 (15:8)
buffer[4] = (unsigned char)  position;       // PositionByte2 (7:0)


      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 


printf("Step done.\n");


close(fd);
}
