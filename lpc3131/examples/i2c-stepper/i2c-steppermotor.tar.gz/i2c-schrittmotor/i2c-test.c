
#include <stdio.h> 
#include <fcntl.h> 
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <unistd.h>

#define ADDR 0x60

int main (int argc, char **argv) { 

    int fd; 
    char filename[32]; 
    char buffer[128]; 
    int n, err; 
    char buffer_help[128];

    if (argc == 0) {
        printf("usage: %s <device>\n", argv[0]);
		    //exit(1);
		}

    sprintf(filename, argv[1]); 
    printf("device = %s\n", filename);

    int slave_address = ADDR; 

    if ((fd = open(filename, O_RDWR)) < 0) { 
        printf("i2c open error"); 
        return -1; 
    } 
    printf("i2c device = %d\n", fd);

    if (ioctl(fd, I2C_SLAVE, slave_address) < 0) { 
        printf("ioctl I2C_SLAVE error"); 
        return -1; 
    } 


    
      //GestFullStatus1 Command
      buffer[0] = 0x81;   

      if (write(fd, buffer, 1) != 1) { 
         printf("write error 0\n"); 
         return -1; 
      } 

     
     
  
      //RunInit command
      buffer[0] = 0x88; 

      if (write(fd, buffer, 1) != 1) { 
         printf("write error 1\n"); 
         return -1; 
      } 



//SetPosition 1
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable
buffer[2] = 0xff;   // not avialable 
buffer[3] = 0x10;   // PositionByte1 (15:8)
buffer[4] = 0x01;   // PositionByte2 (7:0)

      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 

printf("Step 1 done.\n");
sleep(10);




 //SetPosition 2
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable
buffer[2] = 0xff;   // not avialable
buffer[3] = 0xfe;   // PositionByte1 (15:8)
buffer[4] = 0xff;   // PositionByte2 (7:0)

      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 
      
printf("Step 2 done.\n");
sleep(5);



 //SetPosition 3
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable    
buffer[2] = 0xff;   // not avialable
buffer[3] = 0x20;   // PositionByte1 (15:8)
buffer[4] = 0x20;   // PositionByte2 (7:0)

      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 
      
printf("Step 3 done.\n"); 
sleep(10);



 //SetPosition 4
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable    
buffer[2] = 0xff;   // not avialable
buffer[3] = 0xc0;   // PositionByte1 (15:8)
buffer[4] = 0xf0;   // PositionByte2 (7:0)

      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 
      
printf("Step 4 done.\n");      
sleep(10);



 //SetPosition 5
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable    
buffer[2] = 0xff;   // not avialable
buffer[3] = 0xaa;   // PositionByte1 (15:8)
buffer[4] = 0xaa;   // PositionByte2 (7:0)

      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 
      
printf("Step 5 done.\n");      
sleep(10);


 //SetPosition 6
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable    
buffer[2] = 0xff;   // not avialable
buffer[3] = 0x11;   // PositionByte1 (15:8)
buffer[4] = 0x11;   // PositionByte2 (7:0)

      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 
      
printf("Step 6 done.\n");      
sleep(10);


 //SetPosition 7
buffer[0] = 0x8B;   // SetPosition Command
buffer[1] = 0xff;   // not avialable    
buffer[2] = 0xff;   // not avialable
buffer[3] = 0x22;   // PositionByte1 (15:8)
buffer[4] = 0x22;   // PositionByte2 (7:0)

      if (write(fd, buffer, 5) != 5) { 
         printf("write error 2\n"); 
         return -1; 
      } 
      
printf("Step 7 done.\n");      
sleep(10);


printf("Finished\n\n");

}
