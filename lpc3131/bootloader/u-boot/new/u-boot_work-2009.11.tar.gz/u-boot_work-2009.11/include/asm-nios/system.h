#ifndef _ASM_NIOS_SYSTEM_H_
#define _ASM_NIOS_SYSTEM_H_

#endif /* _ASM_NIOS_SYSTEM_H */
