#include <asm-avr32/arch-at32ap700x/mmc.h>
